#!/bin/bash

# Start the Ollama service in the background
echo "Starting Ollama service..."
ollama serve &

# Give Ollama some time to start up (you might need to adjust the sleep time)
sleep 5

# Pull the model if it's not already pulled
if ! ollama list | grep -q "llama3.2:3b"; then
  echo "Pulling llama3.2:3b model..."
  ollama pull llama3.2:3b
else
  echo "Model llama3.2:3b already exists."
fi

# Keep the container running by tailing the logs (optional)
tail -f /dev/null
