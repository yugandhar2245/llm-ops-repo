#!/bin/bash

# Start the Ollama service in the background
echo "Starting Ollama service..."
ollama serve &

# Give Ollama some time to start up (you might need to adjust the sleep time)
sleep 5

# Pull the model if it's not already pulled
if ! ollama list | grep -q "qwen2.5:0.5b"; then
  echo "Pulling qwen2.5:0.5b model..."
  ollama pull qwen2.5:0.5b
else
  echo "Model qwen2.5:0.5b already exists."
fi

# Keep the container running by tailing the logs (optional)
tail -f /dev/null
